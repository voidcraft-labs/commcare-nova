Import this app into CommCare HQ

=== 1. Import the app ===

In CommCare HQ, open the Settings (gear) menu -> Project Settings ->
Import App from Another Server:
  https://www.commcarehq.org/a/<your-project>/settings/project/import_app/

This is the only place CommCare's UI lets you upload an app's JSON. The
first screen asks for an 'App URL' from another server, but it only
checks the URL's shape and that the server differs from yours, it never
opens the link. Paste this exact dummy URL and click Next:

  https://india.commcarehq.org/a/x/apps/view/00000000000000000000000000000000/

(If your CommCare instance IS the India server, change 'india' to 'www'.
 The only rule: the subdomain must be www, india, or eu, and not yours.)

On the next screen, upload "Connect ids.json", name the app, and import.

=== 2. Check the app's CommCare version ===

This app needs CommCare 2.57 or later.

In CommCare HQ, the app's settings show its CommCare version. If the
version there is lower, you can raise it to 2.57 or later and
save.

After that, phones on an older CommCare can no longer install or update
the app.

=== 3. Check what the project space supports ===

This app uses features that CommCare HQ turns on for one project space at
a time:

  - CommCare Connect: The app uses CommCare Connect Learn.

If the project space doesn't have one of these yet, Dimagi support can
turn it on for you: support@dimagi.com. There is
more about each one at https://docs.commcare.app/project-space-compatibility.
