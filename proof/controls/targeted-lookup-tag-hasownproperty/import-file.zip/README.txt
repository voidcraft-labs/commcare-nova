Import this app into CommCare HQ

=== 1. Upload the lookup tables ===

Open the Lookup Tables page in CommCare HQ:
  https://www.commcarehq.org/a/<your-project>/fixtures/

Upload "lookup-tables.xlsx" there, tick "Replace existing
tables", and click Upload Tables. Replacing makes CommCare's copy of
each table in the file match this export exactly. Tables the file
doesn't mention are left alone.

The file carries hasOwnProperty, zz_after. If your project already has a table with one
of those names, uploading replaces its rows.

=== 2. Import the app ===

In CommCare HQ, open the Settings (gear) menu -> Project Settings ->
Import App from Another Server:
  https://www.commcarehq.org/a/<your-project>/settings/project/import_app/

This is the only place CommCare's UI lets you upload an app's JSON. The
first screen asks for an 'App URL' from another server, but it only
checks the URL's shape and that the server differs from yours, it never
opens the link. Paste this exact dummy URL and click Next:

  https://india.commcarehq.org/a/x/apps/view/00000000000000000000000000000000/

(If your CommCare instance IS the India server, change 'india' to 'www'.
 The only rule: the subdomain must be www, india, or eu, and not yours.)

On the next screen, upload "Editor experiment.json", name the app, and import.

=== 3. Check the app's CommCare version ===

This app needs CommCare 2.57 or later.

In CommCare HQ, the app's settings show its CommCare version. If the
version there is lower, you can raise it to 2.57 or later and
save.

After that, phones on an older CommCare can no longer install or update
the app.

=== 4. Check the project space's plan ===

This app uses features that come with some CommCare HQ plans and not others:

  - Web-Based Apps (CloudCare): Advanced and Enterprise. Without it, mobile workers can't open this app in Web Apps, and saving the app's settings in CommCare HQ turns its Web App setting off.
  - Lookup Tables: Standard, Pro, Advanced and Enterprise. Without it, CommCare HQ turns away the tables Nova sends and can't build a form that reads one, and its form builder shows an error on each question whose choices come from cases.

It helps to check that the project space's plan includes each one, on its Current Subscription page in CommCare HQ.
